import React from 'react';
import {
	AppContainer,
	mapStateToProps,
	mapDispatchToProps
} from './App';

/*
	You have access to the shallow() renderer from enzyme. You can add other things you decide you need to the setupTests.js file.
	That will be used to run Jest.
*/

it('maps state to props', () => {
	// Assert that the mapStateToProps function maps correctly given an input of state
});

it('maps dispatchers to props', () => {
	// Assert that that the mapDispatchToProps function has the actions for adding and deleting list items mapped correctly
});

it('renders list items', () => {
	// Here you would be shallow rendering the class, NOT the connected version from react-redux.
	// You can pass in a prop that contains the array of list items and then assert that the view renders as you'd expect it to.
});