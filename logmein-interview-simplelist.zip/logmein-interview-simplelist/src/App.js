import React, { useState } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import logo from './logo.svg';
import './App.css';

import { listAddItem, listRemoveItem } from './modules/list-module';
import { generateId } from './utils/helpers';

export const mapStateToProps = state => ({
  items: state.list.items
});

export const mapDispatchToProps = dispatch => ({
  listAddItem: item => dispatch(listAddItem(item)),
  listRemoveItem: id => dispatch(listRemoveItem(id))
});

export function AppContainer({ items, listAddItem, listRemoveItem }) {
  const [title, setTitle] = useState('');
  const inputChanged = e => setTitle(e.target.value);
  const submitted = e => {
    e.preventDefault();
    listAddItem({ id: generateId(), title });
    setTitle('');
  };

  return (
    <div>
      <header>
        <nav className='navbar navbar-dark bg-dark box-shadow'>
          <div className='navbar-brand'>
            <img
              src={logo}
              width='30'
              height='30'
              className='d-inline-block align-top logo'
              alt=''
            />
            LogMeIn Simple List Management
          </div>
        </nav>
      </header>
      <main role='main' className='container p-5'>
        <form onSubmit={submitted}>
          <div className='form-group row py-4'>
            <label htmlFor='add_item' className='col-sm-2 col-form-label'>
              <strong>Add Item</strong>
            </label>
            <div className='col-sm-10'>
              <input
                type='text'
                id='add_item'
                placeholder='Celebrate and go home!'
                className='form-control'
                value={title}
                onChange={inputChanged}
              />
            </div>
          </div>
        </form>
        <h3>An average day here</h3>
        <ul className='list-group'>
          {items.map(item => (
            <li key={item.id} className='list-group-item'>
              {item.title}
              <button
                type='button'
                className='close text-danger'
                aria-label='Close'
                onClick={() => listRemoveItem(item.id)}
              >
                <span aria-hidden='true'>&times;</span>
              </button>
            </li>
          ))}
        </ul>
      </main>
      <footer>Created by LogMeIn</footer>
    </div>
  );
}

AppContainer.propTypes = {
  items: PropTypes.array,
  listAddItem: PropTypes.func,
  listRemoveItem: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AppContainer);
