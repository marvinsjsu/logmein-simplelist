import { generateId } from '../utils/helpers';

// Initial State
export const initialState = {
  items: [
    {
      id: generateId(),
      title: 'Arrive at the office'
    },
    {
      id: generateId(),
      title: 'Start working on a story in the current sprint'
    },
    {
      id: generateId(),
      title:
        'Get interrupted by the morning standup, losing your train of thought'
    },
    {
      id: generateId(),
      title: 'Finish functionality'
    },
    {
      id: generateId(),
      title: 'Fix all the tests you broke'
    },
    {
      id: generateId(),
      title: 'Write tests for new functionality'
    },
    {
      id: generateId(),
      title: 'Push branch and create a PR'
    }
  ]
};

// Constants
export const LIST_ADD_ITEM = 'LIST_ADD_ITEM';
export const LIST_REMOVE_ITEM = 'LIST_REMOVE_ITEM';

// Selectors

// Action Creators
export const listAddItem = payload => {
  return {
    type: LIST_ADD_ITEM,
    payload
  };
};

export const listRemoveItem = id => {
  return {
    type: LIST_REMOVE_ITEM,
    id
  };
};

// Action Handlers
export const ACTION_HANDLERS = {
  [LIST_ADD_ITEM]: (state, action) => ({
    ...state,
    items: [...state.items, action.payload]
  }),
  [LIST_REMOVE_ITEM]: (state, action) => ({
    ...state,
    items: state.items.filter(item => item.id !== action.id)
  })
};

// Reducer
const listReducer = (state = initialState, action) => {
  const actionHandler = ACTION_HANDLERS[action.type];

  return actionHandler ? actionHandler(state, action) : state;
};

export default listReducer;
