import { combineReducers } from 'redux';
import list from './list-module';

export default combineReducers({
	list
});