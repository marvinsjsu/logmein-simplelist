import ListReducer, {
  initialState,
  listAddItem,
  listRemoveItem,
  LIST_ADD_ITEM,
  LIST_REMOVE_ITEM,
  ACTION_HANDLERS
} from './list-module';

it('has the correct initial state', () => {
  const nonAction = {};
  const listNonHandlerResult = ListReducer(initialState, nonAction);
  expect(JSON.stringify(listNonHandlerResult)).toBe(
    JSON.stringify(initialState)
  );
});

it('has the right values for the constants', () => {
  expect(LIST_ADD_ITEM).toBe('LIST_ADD_ITEM');
  expect(LIST_REMOVE_ITEM).toBe('LIST_REMOVE_ITEM');
});

it('handles the LIST_ADD_ITEM action by updating the state', () => {
  const state = {
    untouched: 'untouched',
    items: []
  };
  const action = {
    payload: {
      title: 'Test'
    }
  };
  const resultantState = ACTION_HANDLERS[LIST_ADD_ITEM](state, action);
  expect(JSON.stringify(resultantState)).toBe(
    JSON.stringify({
      untouched: 'untouched',
      items: [
        {
          title: 'Test'
        }
      ]
    })
  );
});

it('has an action for adding a list item that returns the correct action object', () => {
  const action = listAddItem({ id: 1, title: 'Add Item' });
  expect(JSON.stringify(action)).toBe(
    JSON.stringify({
      type: LIST_ADD_ITEM,
      payload: { id: 1, title: 'Add Item' }
    })
  );
});

it('has an action for deleting a list item that returns the correct action object', () => {
  const action = listRemoveItem(1);
  expect(JSON.stringify(action)).toBe(
    JSON.stringify({
      type: LIST_REMOVE_ITEM,
      id: 1
    })
  );
});

it('handles the LIST_DELETE_ITEM action by updating the state', () => {
  const removeId = initialState.items[0].id;
  const removeAction = listRemoveItem(removeId);
  const expected = {
    ...initialState,
    items: [...initialState.items.filter(item => item.id !== removeId)]
  };
  const listAddItemHandlerResult = ListReducer(initialState, removeAction);
  expect(JSON.stringify(listAddItemHandlerResult)).toBe(
    JSON.stringify(expected)
  );
});

it('returns the correct state for a non-existent action handler', () => {
  const nonAction = {};
  const listNonHandlerResult = ListReducer(initialState, nonAction);
  expect(JSON.stringify(listNonHandlerResult)).toBe(
    JSON.stringify(initialState)
  );
});

it('returns the correct state for a registered action handler', () => {
  // positive case for the listReducer
  const addAction = listAddItem({ title: 'Add Test' });
  const expected = {
    ...initialState,
    items: [...initialState.items, { title: 'Add Test' }]
  };
  const listAddItemHandlerResult = ListReducer(initialState, addAction);
  expect(JSON.stringify(listAddItemHandlerResult)).toBe(
    JSON.stringify(expected)
  );
});
