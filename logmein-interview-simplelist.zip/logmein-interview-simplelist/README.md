# Interview Project
The goal of this project is to convert a static ToDo list into a dynamic list using React/Redux, then write some basic tests for it.
Some of the work has already been done, but feel free to refactor, add, and remove as much as you feel is necessary to get it working.

## Installation

#### 1. Create a new project from the unzipped source code in your favorite Integrated Development Environment (IDE)
You can use any IDE like WebStorm, Sublime, Atom, Komodo, Visual Studio Code, etc.

#### 2. Install the application using Node Package Manager (NPM).
```
$ npm install
```
If you don't already have Node.js and NPM installed on your system then follow the download and installation instructions at https://nodejs.org/en/ 

#### 3. Test that your application has been correctly set up.
```
$ npm start
```
This should open your default browser running http://localhost:3000 that displays the landing page of this project (a daily to-do list with a field to add items, and a list of items pre-populated in a table below it)

#### 4. Complete the Tasks section below, and test your code
```
$ npm test
```

## Tasks
#### 1. Convert the static list in `App.js` to use information stored in Redux
To help you get started, the information has been pre-populated in the initial state (see `/src/modules/list-module.js`)

#### 2. Hook up the input form to allow new items to be added to the list
Use whatever UX you like (e.g., Enter to submit, Button)

An example handler has already been created for you for the `LIST_ADD_ITEM` use case, but tailor it to fit your needs.

#### 3. Hook up the close button to delete the appropriate item from the list

#### 4. Fill in the tests in `App.test.js` and `list-module.test.js`

If you have any trouble or questions, reach out to `joe.nagy@logmein.com` or `john.spann@logmein.com`

If you encounter any difficulties you can ZIP up your project (without node_modules) and send it along.

## Project submission

#### When you completed the project ZIP its contents (without node-modules) and upload it to github and email the link to your recruiter
